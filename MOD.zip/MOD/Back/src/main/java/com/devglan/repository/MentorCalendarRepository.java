package com.devglan.repository;


import java.sql.Time;
import java.util.Date;
import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.devglan.model.MentorCalender;


public interface MentorCalendarRepository extends PagingAndSortingRepository<MentorCalender, Long> {


	String findMentorCalendarByMentorId = "SELECT * FROM Mentor_Calendar mc "
			+ "WHERE mc.mentor_id=?1 AND (mc.start_date BETWEEN ?2 AND ?3 AND mc.end_date BETWEEN ?2 AND ?3) ";
	@Query(value = findMentorCalendarByMentorId + " ORDER BY mc.start_date", 
			nativeQuery = true)
	List<MentorCalender> findMentorCalendarByMentorId(String mentor_id, Date startDate, Date endDate);

	@Query(value = "SELECT * FROM Mentor_Calendar mc " 
	        + "WHERE mc.mentor_id=?1 AND "
			+ "(mc.start_date BETWEEN ?2 AND ?3 AND mc.end_date BETWEEN ?2 AND ?3) AND "
			+ "(mc.start_time BETWEEN ?4 AND ?5 AND mc.end_time BETWEEN ?4 AND ?5) ", 
			nativeQuery = true)
	List<MentorCalender> findCalendarEntry(String mentorId, Date startDate, Date endDate, Time startTime, Time endTime);

}
