package com.devglan.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.devglan.model.Mentor;
import com.devglan.model.Skills;
import com.devglan.model.Trainings;
import com.devglan.model.TrainingsModel;
import com.devglan.repository.MentorRepository;
import com.devglan.repository.SkillsRepository;
import com.devglan.repository.TrainingsRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")

public class TrainingsController {
	
	@Autowired
	TrainingsRepository repository;
	
	@Autowired
	MentorRepository mrepository;
	
	@Autowired
	SkillsRepository srepository;

	@GetMapping("/trainings")
	public List<Trainings> getAllTrainings() {
		System.out.println("Get all Trainings...");

		List<Trainings> trainings = new ArrayList<>();
		repository.findAll().forEach(trainings::add);

		return trainings;
	}
	
	
	
	@GetMapping(value = "/getTrainings/{id}")
	public List<Trainings> findById(@PathVariable String id) {
		System.out.println("Get Trainings by Id...");
		List<Trainings> trainings = repository.findByUser_id(id);
		return trainings;
	}
	

	@GetMapping(value = "/getTrainings")
	public List<Trainings> findBy() {
		System.out.println("Get Trainings by Id...");
		String id="761261";
		List<Trainings> trainings = repository.findByUser_id(id);
		return trainings;
	}
	
	@GetMapping(value = "getTrainingsUnderProgress/{status}")
	public List<Trainings> findByStatus(@PathVariable int status) {

		List<Trainings> trainings = repository.findByStatus(status);
		return trainings;
	}
	
	@PostMapping(value = "/trainings/create")
	public Trainings postTrainings(@RequestBody Trainings training) {

		Trainings _customer = repository.save(new Trainings(training.getId(), training.getUser_id(), training.getMentor_id(),training.getSkill_id(),
				training.getStatus(),training.getProgress(),training.getRating(),training.getStart_time(),training.getEnd_time(),training.getStart_date(),
				training.getEnd_date(),training.getAmount_received()));
		return _customer;
	}
	
	@DeleteMapping("/trainings/delete/{id}")
	public ResponseEntity<String> deleteTrainings(@PathVariable("id") long id) {
		System.out.println("Delete Trainings with ID = " + id + "...");

		repository.deleteById(id);

		return new ResponseEntity<>("Training has been deleted!", HttpStatus.OK);
	}
	
	@GetMapping(value = "getUnderProgressTrainings/{id}")
	public List<Trainings> findUnderProgress(@PathVariable String id) {

		List<Trainings> trainings = repository.findByUser_id(id);
		return trainings;
	}
	
	@GetMapping("/getCompletedTrainings")
	List<TrainingsModel> getCompletedTrainings()
	{
		String id="761261";
		List<Trainings> Trainings_list = repository.findByUser_id(id);
		List<TrainingsModel> Trainingsm_list = new ArrayList<TrainingsModel>();
		for(Trainings Trainings:Trainings_list)
		{
			String mentor_id = Trainings.getMentor_id();
			String skill_id=Trainings.getSkill_id();
			Optional<Mentor> mentor = mrepository.findByMentor_id(mentor_id);
			Optional<Skills> skills = srepository.findBySkill_id(skill_id);
			TrainingsModel tmodel = new TrainingsModel(Trainings.getId(),
					Trainings.getUser_id(), mentor.get().getFirstname(),Trainings.getStatus(),
					Trainings.getProgress(), skills.get().getName(),Trainings.getEnd_date(),Trainings.getRating());
			
			Trainingsm_list.add(tmodel);
		}
		
		return Trainingsm_list;
	}
	
	@PutMapping("/training/status/{id}")
	public void updateStatus(@PathVariable("id") Long id) {
		System.out.println("Update Customer with ID = " + id + "...");
		int status=3;

	repository.setStatusForTrainings(status,id);

	}
	
	
	
	

}
