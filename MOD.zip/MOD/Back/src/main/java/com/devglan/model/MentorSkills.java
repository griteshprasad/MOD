package com.devglan.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="mentor_skills")
public class MentorSkills {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column(name = "mentor_id")
	private String mentor_id;
	
	@Column(name = "skill_id")
	private String skill_id;
	
	@Column(name = "self_rating")
	private float self_rating;
	
	@Column(name = "experience")
	private int experience;
	
	@Column(name = "trainings_delivered")
	private int trainings_delivered;
	
	@Column(name = "facilities")
	private String facilities;
	
	
	
	public MentorSkills()
	{
		
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getMentor_id() {
		return mentor_id;
	}

	public void setMentor_id(String mentor_id) {
		this.mentor_id = mentor_id;
	}

	public String getSkill_id() {
		return skill_id;
	}

	public void setSkill_id(String skill_id) {
		this.skill_id = skill_id;
	}

	public float getSelf_rating() {
		return self_rating;
	}

	public void setSelf_rating(float self_rating) {
		this.self_rating = self_rating;
	}

	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	public int getTrainings_delivered() {
		return trainings_delivered;
	}

	public void setTrainings_delivered(int trainings_delivered) {
		this.trainings_delivered = trainings_delivered;
	}

	public String getFacilities() {
		return facilities;
	}

	public void setFacilities(String facilities) {
		this.facilities = facilities;
	}

	public MentorSkills(long id, String mentor_id, String skill_id, float self_rating, int experience,
			int trainings_delivered, String facilities) {
		super();
		this.id = id;
		this.mentor_id = mentor_id;
		this.skill_id = skill_id;
		this.self_rating = self_rating;
		this.experience = experience;
		this.trainings_delivered = trainings_delivered;
		this.facilities = facilities;
	}

	@Override
	public String toString() {
		return "MentorSkills [id=" + id + ", mentor_id=" + mentor_id + ", skill_id=" + skill_id + ", self_rating="
				+ self_rating + ", experience=" + experience + ", trainings_delivered=" + trainings_delivered
				+ ", facilities=" + facilities + "]";
	}

	
	
	

}
