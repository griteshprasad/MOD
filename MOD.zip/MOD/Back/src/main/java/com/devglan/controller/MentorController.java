package com.devglan.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.devglan.model.Mentor;
import com.devglan.model.MentorModel;
import com.devglan.repository.MentorRepository;
import com.devglan.repository.MentorSkillsRepository;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")

public class MentorController {
	
	@Autowired
	MentorRepository repository;
	
	@Autowired
	MentorSkillsRepository mrepository;
	
	@GetMapping("/mentors")
	public List<Mentor> getAllMentors() {
		System.out.println("Get all Mentors...");

		List<Mentor> mentors = new ArrayList<>();
		repository.findAll().forEach(mentors::add);

		return mentors;
	}
	
	@GetMapping(value = "/getMentors")
	public String findById() {
		return "hello";
	}
	
	@GetMapping(value = "/getMentor/id/{mid}")
	public Optional<Mentor> findById(@PathVariable String mid) {
		Optional<Mentor> mentors=repository.findByMentor_id(mid);
		return mentors;
	}
	@PostMapping(value = "/mentor/create")
	public Mentor postTrainings(@RequestBody Mentor mentor) {

		Mentor _customer = repository.save(new Mentor(mentor.getId(),mentor.getMentor_id(),mentor.getFirstname(),mentor.getLastname(),mentor.getLinkedin_url(),mentor.getRegdate(),mentor.getCode(),mentor.getExperience(),mentor.isActive()));
		return _customer;
	}
	
	
	
	
	

}

