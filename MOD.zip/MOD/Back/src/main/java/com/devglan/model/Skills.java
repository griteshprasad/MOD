package com.devglan.model;

import java.sql.Time;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="skills")
public class Skills {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column(name = "skill_id")
	private String skill_id;
	
	@Column(name = "name")
	private String name;
	
	@Column(name = "toc")
	private String toc;
	
	@Column(name = "duration")
	private Time duration;
	
	@Column(name = "prerequites")
	private String prerequites;
	
	public Skills() {
		
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getSkill_id() {
		return skill_id;
	}

	public void setSkill_id(String skill_id) {
		this.skill_id = skill_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getToc() {
		return toc;
	}

	public void setToc(String toc) {
		this.toc = toc;
	}

	public Time getDuration() {
		return duration;
	}

	public void setDuration(Time duration) {
		this.duration = duration;
	}

	public String getPrerequites() {
		return prerequites;
	}

	public void setPrerequites(String prerequites) {
		this.prerequites = prerequites;
	}

	@Override
	public String toString() {
		return "Skills [id=" + id + ", skill_id=" + skill_id + ", name=" + name + ", toc=" + toc + ", duration="
				+ duration + ", prerequites=" + prerequites + "]";
	}

	public Skills(long id, String skill_id, String name, String toc, Time duration, String prerequites) {
		super();
		this.id = id;
		this.skill_id = skill_id;
		this.name = name;
		this.toc = toc;
		this.duration = duration;
		this.prerequites = prerequites;
	}

	
	
	
	
	

}
