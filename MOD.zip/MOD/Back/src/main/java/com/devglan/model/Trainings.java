package com.devglan.model;


import java.sql.Date;
import java.sql.Time;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="trainings")
public class Trainings {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column(name = "user_id")
	private String user_id;
	
	@Column(name = "mentor_id")
	private String mentor_id;

	@Column(name = "skill_id")
	private String skill_id;
	
	@Column(name = "status")
	private int status;
	
	@Column(name = "progress")
	private int progress;
	
	@Column(name = "rating")
	private float rating;
	
	@Column(name = "start_time")
	private Time start_time;
	
	@Column(name = "end_time")
	private Time end_time;
	
	@Column(name = "start_date")
	private Date start_date;
	
	@Column(name = "end_date")
	private Date end_date;
	
	@Column(name = "amount_received")
	private int amount_received;
	
	public Trainings()
	{
		
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getMentor_id() {
		return mentor_id;
	}

	public void setMentor_id(String mentor_id) {
		this.mentor_id = mentor_id;
	}

	public String getSkill_id() {
		return skill_id;
	}

	public void setSkill_id(String skill_id) {
		this.skill_id = skill_id;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public int getProgress() {
		return progress;
	}

	public void setProgress(int progress) {
		this.progress = progress;
	}

	public float getRating() {
		return rating;
	}

	public void setRating(float rating) {
		this.rating = rating;
	}

	public Time getStart_time() {
		return start_time;
	}

	public void setStart_time(Time start_time) {
		this.start_time = start_time;
	}

	public Time getEnd_time() {
		return end_time;
	}

	public void setEnd_time(Time end_time) {
		this.end_time = end_time;
	}

	public Date getStart_date() {
		return start_date;
	}

	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}

	public Date getEnd_date() {
		return end_date;
	}

	public void setEnd_date(Date end_date) {
		this.end_date = end_date;
	}

	public int getAmount_received() {
		return amount_received;
	}

	public void setAmount_received(int amount_received) {
		this.amount_received = amount_received;
	}

	public Trainings(long id, String user_id, String mentor_id, String skill_id, int status, int progress, float rating,
			Time start_time, Time end_time, Date start_date, Date end_date, int amount_received) {
		super();
		this.id = id;
		this.user_id = user_id;
		this.mentor_id = mentor_id;
		this.skill_id = skill_id;
		this.status = status;
		this.progress = progress;
		this.rating = rating;
		this.start_time = start_time;
		this.end_time = end_time;
		this.start_date = start_date;
		this.end_date = end_date;
		this.amount_received = amount_received;
	}

	@Override
	public String toString() {
		return "Trainings [id=" + id + ", user_id=" + user_id + ", mentor_id=" + mentor_id + ", skill_id=" + skill_id
				+ ", status=" + status + ", progress=" + progress + ", rating=" + rating + ", start_time=" + start_time
				+ ", end_time=" + end_time + ", start_date=" + start_date + ", end_date=" + end_date
				+ ", amount_received=" + amount_received + "]";
	}
	
	
	
	
	
	
	
	
}
