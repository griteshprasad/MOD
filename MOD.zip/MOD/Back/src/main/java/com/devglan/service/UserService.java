package com.devglan.service;

import com.devglan.model.User;
//import com.devglan.model.UserData;
import com.devglan.model.UserDto;

import java.util.List;

public interface UserService {

    User save(UserDto user);
    List<User> findAll();

    User findOne(String email);

    UserDto update(UserDto userDto);
	void delete(long id);
	User findById(long id);
    
    //UserData saves(UserData user);
    //List<UserData> findAlll();
}
