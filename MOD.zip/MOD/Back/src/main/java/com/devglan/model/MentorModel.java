package com.devglan.model;

import java.util.List;

public class MentorModel {

	
	private long id;

	private String name;

	private int experience;
	
	private List skills;
	
	private String url;

	public MentorModel(){
		
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	public List getSkills() {
		return skills;
	}

	public void setSkills(List<Skills> skills) {
		this.skills = skills;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	@Override
	public String toString() {
		return "MentorModel [id=" + id + ", name=" + name + ", experience=" + experience + ", skills=" + skills
				+ ", url=" + url + "]";
	}

	public MentorModel(long id, String name, int experience, List skills, String url) {
		super();
		this.id = id;
		this.name = name;
		this.experience = experience;
		this.skills = skills;
		this.url = url;
	}


}
