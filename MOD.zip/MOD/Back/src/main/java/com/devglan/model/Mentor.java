package com.devglan.model;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


@Entity
@Table(name="mentor")
public class Mentor {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@NotNull
    @Email
	@Column(name = "mentor_id")
	private String mentor_id;
	
	@Column(name = "firstname")
	private String firstname;
	
	@Column(name = "lastname")
	private String lastname;
	
	@Column(name = "linkedin_url")
	private String linkedin_url;
	
	@Column(name = "regdate")
	private Date regdate;
	
	@Column(name = "code")
	private String code;
	
	@Column(name = "experience")
	private int experience;
	
	@Column(name = "active")
	private boolean active;
	
	
	
	
	public Mentor()
	{
		
	}
	
	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getMentor_id() {
		return mentor_id;
	}

	public void setMentor_id(String mentor_id) {
		this.mentor_id = mentor_id;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getLinkedin_url() {
		return linkedin_url;
	}

	public void setLinkedin_url(String linkedin_url) {
		this.linkedin_url = linkedin_url;
	}

	public Date getRegdate() {
		return regdate;
	}

	public void setRegdate(Date regdate) {
		this.regdate = regdate;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public Mentor(long id, String mentor_id, String firstname, String lastname, String linkedin_url, Date regdate,
			String code, int experience, boolean active) {
		super();
		this.id = id;
		this.mentor_id = mentor_id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.linkedin_url = linkedin_url;
		this.regdate = regdate;
		this.code = code;
		this.experience = experience;
		this.active = active;
	}

	@Override
	public String toString() {
		return "Mentor [id=" + id + ", mentor_id=" + mentor_id + ", firstname=" + firstname + ", lastname=" + lastname
				+ ", linkedin_url=" + linkedin_url + ", regdate=" + regdate + ", code=" + code + ", experience="
				+ experience + ", active=" + active + "]";
	}
	
	

	
}
