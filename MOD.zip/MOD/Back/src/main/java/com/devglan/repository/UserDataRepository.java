package com.devglan.repository;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.devglan.model.User;
import com.devglan.model.UserData;

import io.jsonwebtoken.lang.Objects;



public interface UserDataRepository extends CrudRepository<UserData, Long> {

	UserData findByUsername(String username);
	
}
