package com.devglan.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.devglan.model.MentorSkills;
import com.devglan.model.Skills;



public interface SkillsRepository extends CrudRepository<Skills, Long>{

	@Query(value = "SELECT ms FROM Skills ms WHERE ms.skill_id=?1")
	Optional<Skills> findBySkill_id(String id);
	List<Skills> findByName(String name);
	
	
}
