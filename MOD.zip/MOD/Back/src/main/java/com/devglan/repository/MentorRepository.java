package com.devglan.repository;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.devglan.model.Mentor;
import com.devglan.model.MentorModel;




public interface MentorRepository extends CrudRepository<Mentor, Long> {

	
	List<Mentor> findById(long id);
	//List<Mentor> findByMentorid(int mid);
	@Query(value = "SELECT ms FROM Mentor ms WHERE ms.mentor_id=?1")
	Optional<Mentor> findByMentor_id(String s);
		
	/*@Query(value = "SELECT m.firstname,m.experience,s.name,m.linkedin_url from mentor m,mentor_skills ms,skills s "
			+ "where m.mentor_id=ms.mentor_id and ms.skill_id=s.skill_id",nativeQuery=true)
	Optional<MentorModel> findMentors();
	*/
	
	
	
}
