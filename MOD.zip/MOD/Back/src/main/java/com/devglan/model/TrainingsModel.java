package com.devglan.model;

import java.util.Date;

public class TrainingsModel {

	
	private long id;

	private String user_id;

	private String mentor_username;

	private int status;
	
	private int progress;
	
	private String name;
	private Date end_date;
	private float rating;

	public TrainingsModel(){
		
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getMentor_username() {
		return mentor_username;
	}

	public void setMentor_username(String mentor_username) {
		this.mentor_username = mentor_username;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public int getProgress() {
		return progress;
	}

	public void setProgress(int progress) {
		this.progress = progress;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getEnd_date() {
		return end_date;
	}

	public void setEnd_date(Date end_date) {
		this.end_date = end_date;
	}

	public float getRating() {
		return rating;
	}

	public void setRating(float rating) {
		this.rating = rating;
	}

	@Override
	public String toString() {
		return "TrainingsModel [id=" + id + ", user_id=" + user_id + ", mentor_username=" + mentor_username
				+ ", status=" + status + ", progress=" + progress + ", name=" + name + ", end_date=" + end_date
				+ ", rating=" + rating + "]";
	}

	public TrainingsModel(long id, String user_id, String mentor_username, int status, int progress, String name,
			Date end_date, float rating) {
		super();
		this.id = id;
		this.user_id = user_id;
		this.mentor_username = mentor_username;
		this.status = status;
		this.progress = progress;
		this.name = name;
		this.end_date = end_date;
		this.rating = rating;
	}

	

}
