package com.devglan.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.devglan.model.Trainings;


public interface TrainingsRepository extends CrudRepository<Trainings, Long> {

	List<Trainings> findById(long id);
	
	@Query(value = "SELECT ms FROM Trainings ms WHERE ms.user_id=?1")
	List<Trainings> findByUser_id(String uid);
	List<Trainings> findByStatus(int status);
	
	
	@Query(value="select T from trainings T where T.status!=5 and T.user_id=?1",nativeQuery=true)
	
	List<Trainings> findByStat(String uid);
	
	@Modifying(clearAutomatically = true)
	@Transactional
	@Query("update Trainings r set r.status = ?1 where r.id = ?2")
	void setStatusForTrainings(int status, Long id);
	
}

