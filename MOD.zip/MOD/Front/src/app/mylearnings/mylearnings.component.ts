import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { CustomerService } from '../customer.service';
import { Training } from '../training';

@Component({
  selector: 'app-mylearnings',
  templateUrl: './mylearnings.component.html',
  styleUrls: ['./mylearnings.component.css']
})
export class MylearningsComponent implements OnInit {

  trainings: Observable<Training[]>;

  constructor(private customerService: CustomerService) { }

  ngOnInit() {
    this.reloadData();
  }
  
  reloadData() {
    this.trainings = this.customerService.getTrainings();
  }

}
