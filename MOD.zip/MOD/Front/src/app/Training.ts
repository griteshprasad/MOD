export class Training{
    id:number;
    userid:number;
    mentor_username:string;
    status:String;
    progress:number;
    name:string;
    end_date:String;
    rating:string;

}